"""Generate unstarted eNSP training projects and device-specific command files."""
import argparse
import json
import re
import secrets
from pathlib import Path
from uuid import uuid4
from xml.etree import ElementTree

ASSETS = Path(__file__).resolve().parent.parent / "assets"
LABS = {
    "vlan": ("01-vlan", "vlan"),
    "inter-vlan": ("02-inter-vlan", "inter-vlan"),
    "static": ("03-static", "triangle"),
    "ospf": ("04-ospf", "triangle"),
}
TRIANGLE = {
    "R1": ((0, "10.0.12.1"), (1, "10.0.13.1")),
    "R2": ((0, "10.0.12.2"), (1, "10.0.23.2")),
    "R3": ((1, "10.0.13.3"), (2, "10.0.23.3")),
}


def interface(number, *settings):
    return [f"interface GigabitEthernet0/0/{number}", *settings, "quit"]


def access(number, vlan):
    return interface(number, "port link-type access", f"port default vlan {vlan}")


def trunk(number, vlans):
    return interface(number, "port link-type trunk", f"port trunk allow-pass vlan {vlans}")


def vlanif(vlan, ip):
    return [f"interface Vlanif {vlan}", f"ip address {ip} 24", "quit"]


def static_route(destination, hop, preference=None, prefix=32):
    command = f"ip route-static {destination} {prefix} {hop}"
    return command if preference is None else f"{command} preference {preference}"


def vlan_stages():
    return {
        "base": {
            "R1": interface(1, "ip address 10.1.2.1 24"),
            "R3": [
                *interface(2, "ip address 10.1.10.1 24"),
                static_route("10.1.2.0", "GigabitEthernet0/0/2", prefix=24),
            ],
            "S1": ["vlan batch 2 3 10", *access(1, 2), *access(13, 3), *trunk(10, "2 3 10")],
            "S2": [
                "vlan batch 2 3 10", *access(14, 3), *trunk(10, "2 3 10"),
                *interface(1, "port link-type hybrid", "port hybrid untagged vlan 10", "mac-vlan enable"),
            ],
            "S3": ["vlan batch 3", *access(1, 3), *vlanif(3, "10.1.3.1")],
            "S4": ["vlan batch 3", *access(2, 3), *vlanif(3, "10.1.3.2")],
        },
        "bind-mac": {"S2": ["vlan 10", "mac-vlan mac-address {{R3_MAC}}", "quit"]},
    }


def inter_vlan_stages():
    base = {
        "R1": [
            command
            for vlan in (2, 3)
            for command in interface(
                f"1.{vlan}", f"dot1q termination vid {vlan}",
                f"ip address 192.168.{vlan}.254 24", "arp broadcast enable",
            )
        ],
        "S1": ["vlan batch 2 3", *access(2, 2), *access(3, 3), *trunk(1, "2 3")],
    }
    for vlan in (2, 3):
        base[f"R{vlan}"] = [
            *interface(1, f"ip address 192.168.{vlan}.1 24"),
            static_route("0.0.0.0", f"192.168.{vlan}.254", prefix=0),
        ]
    return {
        "base": base,
        "vlanif": {
            "R1": [
                "undo interface GigabitEthernet0/0/1.2",
                "undo interface GigabitEthernet0/0/1.3",
            ],
            "S1": [
                *interface(1, "undo port trunk allow-pass vlan 2 3", "undo port link-type"),
                *vlanif(2, "192.168.2.254"), *vlanif(3, "192.168.3.254"),
            ],
        },
    }


def triangle_base():
    base = {}
    for role, links in TRIANGLE.items():
        commands = [
            command
            for port, address in links
            for command in interface(port, f"ip address {address} 24")
        ]
        commands.extend(["interface LoopBack0", f"ip address 10.0.1.{role[-1]} 32", "quit"])
        base[role] = commands
    return base


def static_stages():
    return {
        "base": triangle_base(),
        "routes": {
            "R1": [
                static_route("10.0.1.2", "10.0.12.2"),
                static_route("10.0.1.2", "10.0.13.3", 100),
                static_route("10.0.1.3", "10.0.13.3"),
            ],
            "R2": [
                static_route("10.0.1.1", "10.0.12.1"),
                static_route("10.0.1.1", "10.0.23.3", 100),
                static_route("10.0.1.3", "10.0.23.3"),
            ],
            "R3": [
                static_route("10.0.1.1", "10.0.13.1"),
                static_route("10.0.1.2", "10.0.23.2"),
            ],
        },
    }


def ospf_stages():
    key = "Lab" + secrets.token_hex(6)
    process = {}
    for role, links in TRIANGLE.items():
        loopback = f"10.0.1.{role[-1]}"
        process[role] = [
            f"ospf 1 router-id {loopback}", "area 0",
            *(f"network {address} 0.0.0.0" for _, address in links),
            f"network {loopback} 0.0.0.0",
        ]
    auth = f"authentication-mode md5 1 cipher {key}"
    return {
        "base": triangle_base(),
        "process": process,
        "auth-interface": {
            role: [
                command
                for port, _ in TRIANGLE[role]
                for command in interface(port, "ospf " + auth)
            ]
            for role in ("R1", "R2")
        },
        "auth-area": {"R3": ["ospf 1", "area 0", auth]},
        "advertise": {"R1": ["ospf 1", "default-route-advertise always"]},
        "cost": {"R1": interface(0, "ospf cost 10")},
    }


def command_stages(lab):
    factories = {
        "vlan": vlan_stages,
        "inter-vlan": inter_vlan_stages,
        "static": static_stages,
        "ospf": ospf_stages,
    }
    return factories[lab]()


def new_mac(old, used):
    while True:
        random_bits = secrets.randbelow(1 << 21) * 8
        tail = random_bits.to_bytes(3, "big").hex("-").upper()
        candidate = old[:9] + tail
        if candidate not in used:
            used.add(candidate)
            return candidate


def prepare_topology(asset, suffix, used_macs):
    data = asset.read_text(encoding="ascii")
    root = ElementTree.fromstring(data)
    devices = {}
    replacements = {}
    for node in root.findall("./devices/dev"):
        role = node.attrib["name"]
        name = f"{role}-{suffix}" if suffix else role
        ident = node.attrib["id"]
        mac = node.attrib["system_mac"]
        replacements[ident] = str(uuid4()).upper()
        replacements[mac] = new_mac(mac, used_macs)
        replacements[f'name="{role}"'] = f'name="{name}"'
        devices[role] = {
            "name": name,
            "model": node.attrib["model"],
            "console_port": int(node.attrib["com_port"]),
        }
    for old, new in replacements.items():
        data = data.replace(old, new)
    return data, devices


def build(destination, suffix, labs):
    destination.mkdir(parents=True, exist_ok=False)
    used_macs = set()
    for lab in labs:
        directory, asset = LABS[lab]
        project = destination / directory
        project.mkdir()
        xml, devices = prepare_topology(ASSETS / f"{asset}.topo", suffix, used_macs)
        topology = project / f"{directory}.topo"
        topology.write_bytes(xml.encode("ascii"))
        stages = {}
        for stage, entries in command_stages(lab).items():
            command_dir = project / "commands" / stage
            command_dir.mkdir(parents=True)
            stages[stage] = {}
            for role, commands in entries.items():
                name = devices[role]["name"]
                prefix = ["system-view", f"sysname {name}"] if stage == "base" else ["system-view"]
                cfg = command_dir / f"{role}.txt"
                cfg.write_text("\n".join([*prefix, *commands, "return", ""]), encoding="ascii")
                stages[stage][role] = cfg.relative_to(project).as_posix()
        manifest = {"topology": topology.name, "devices": devices, "stages": stages}
        (project / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
        print(topology)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("destination", type=Path, help="new directory")
    parser.add_argument("--suffix", default="", help="optional device-name suffix, e.g. AB")
    parser.add_argument("--lab", action="append", choices=list(LABS), help="repeat to select several labs")
    args = parser.parse_args()
    if args.suffix and not re.fullmatch(r"[A-Za-z0-9]{1,12}", args.suffix):
        parser.error("--suffix must have 1 to 12 ASCII letters or digits")
    if args.destination.exists():
        parser.error("destination already exists; supply a new directory")
    selected = set(args.lab) if args.lab else set(LABS)
    build(args.destination.resolve(), args.suffix, [lab for lab in LABS if lab in selected])


if __name__ == "__main__":
    main()
