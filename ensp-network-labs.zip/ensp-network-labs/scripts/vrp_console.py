"""Send a small, explicit VRP command list to an active local eNSP console."""
import argparse
import re
import socket
import sys
import time
from contextlib import nullcontext
from pathlib import Path

ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
USER_PROMPT = re.compile(r"(?m)^<([^<>\r\n]+)>\s*\Z")
PROMPT = re.compile(r"(?m)^(?:<[^<>\r\n]+>|\[[^\[\]\r\n]+\])\s*\Z")
CONFIRM = re.compile(r"(?:\[[YN]/[YN]\]|\([YN]/[YN]\)).{0,20}\s*\Z", re.I)
REJECTED = re.compile(
    r"(?mi)^\s*(?:Error:|Unrecognized command|Wrong parameter|Incomplete command)"
)


def cleaned(data):
    text = data.decode("utf-8", "replace").replace("\x00", "").replace("\r", "")
    return ANSI.sub("", text)


def receive(client, timeout):
    data = bytearray()
    deadline = time.monotonic() + timeout
    pager = b"---- More ----"
    while time.monotonic() < deadline:
        try:
            part = client.recv(65536)
        except TimeoutError:
            text = cleaned(data)
            if PROMPT.search(text) or CONFIRM.search(text):
                return text
            if text.rstrip().endswith(pager.decode("ascii")):
                start = data.rfind(pager)
                del data[start : start + len(pager)]
                data.extend(b"\n")
                client.sendall(b" ")
            continue
        if not part:
            detail = cleaned(data).strip()
            raise RuntimeError(f"Console disconnected. Last output: {detail[-400:]!r}")
        data.extend(part)
    detail = cleaned(data).strip()
    raise RuntimeError(f"No usable prompt within {timeout:g} s. Last output: {detail[-400:]!r}")


def read_commands(args, parser):
    try:
        lines = args.file.read_text(encoding="utf-8-sig").splitlines() if args.file else args.cmd or []
        commands = [line.strip() for line in lines if line.strip() and not line.lstrip().startswith("#")]
        for command in commands:
            if "{{" in command or "}}" in command:
                parser.error(f"replace the placeholder before running: {command}")
            if not command.isascii() or any(ord(c) < 32 for c in command):
                parser.error("commands must use printable ASCII on a single line")
        return commands
    except (OSError, UnicodeError) as err:
        parser.error(str(err))


def run(port, commands, expect, timeout, write):
    with socket.create_connection(("127.0.0.1", port), timeout=min(timeout, 4)) as client:
        client.settimeout(0.25)
        client.sendall(b"\r")
        initial = receive(client, timeout)
        write(initial)
        if not commands:
            return
        actual = USER_PROMPT.search(initial)
        if actual is None or actual[1] != expect:
            raise RuntimeError(f"Expected user-view prompt <{expect}>. No commands sent.")
        for command in commands:
            client.sendall(command.encode("ascii") + b"\r")
            response = receive(client, timeout)
            write(response)
            if CONFIRM.search(response):
                raise RuntimeError("Device requested confirmation. Complete or cancel in its console.")
            if REJECTED.search(response):
                raise RuntimeError(f"Device rejected {command!r}. Prior commands may have taken effect.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("port", type=int, help="local console port from the active eNSP project")
    parser.add_argument("--expect", help="exact current VRP name as shown in <user view>")
    command = parser.add_mutually_exclusive_group()
    command.add_argument("--file", type=Path, help="one VRP command per line")
    command.add_argument("--cmd", action="append", help="repeat for several commands")
    parser.add_argument("--log", type=Path, help="optional new UTF-8 transcript, excludes screenshots")
    parser.add_argument("--timeout", type=float, default=25, help="per-command wait in seconds")
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error("port must be between 1024 and 65535")
    if not 1 <= args.timeout <= 180:
        parser.error("timeout must be between 1 and 180 seconds")
    commands = read_commands(args, parser)
    if commands and not args.expect:
        parser.error("probe the console first, then set --expect to the observed name")
    try:
        with args.log.open("x", encoding="utf-8") if args.log else nullcontext() as log:
            def write(output):
                line = output.strip("\n") + "\n"
                print(line, end="", flush=True)
                if log:
                    log.write(line)
                    log.flush()

            run(args.port, commands, args.expect, args.timeout, write)
    except (OSError, RuntimeError) as err:
        print(f"eNSP console: {err}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
